class GameShare extends Phaser.Scene {

    constructor ()
    {
        super({ key: 'GameShare', active: false });

    }



    create ()
    {

        this.scene.start("scene1");

    }

    
    

}
